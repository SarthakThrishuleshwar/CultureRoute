# PS-01 — your data model

**SmartTrip — AI Travel Planner**  
Kognivera Hackathon 2026 · Travel & Tourism · data model v1.1.0-rc1

> **The problem statement itself, the 24-hour MVP scope and the XR device requirement live in the hackathon application**, on your statement's page. This document is the data you have been given to build it with: every table, every field, and what each one is for.

---

You have **32,627 rows across 18 tables**. 17 of them are the tables this statement is built on; the remaining 1 is a reference table the others point at, included so the database works on its own.

All of it is in the `data/` folder beside this document: as `PS-01.db` (SQLite, indexed, ready to query), as CSV, and as DDL for Postgres and SQLite.

## What the data gives you

60 cities with a written knowledge base, 900 POIs with real durations and costs, 4,000 dated flights, and an existing trip/itinerary spine your planner writes into.

## Watch out for this one

`itinerary_items.source` and `.explanation` are what make a mixed human/AI plan auditable. Write them; do not leave them null.

## The tables this statement is built on

| Table | Rows | What you use it for |
|---|---|---|
| `activities_poi` | 900 | Points of interest with real depth — cost, duration, carbon, hours and tags — because APS-09 optimises over exactly these fields. |
| `cities` | 60 | The geographic anchor of the whole model. 60 cities; every hotel, POI, package, advisory and weather row hangs off one. |
| `countries` | 30 | ISO country reference. Every city, currency default and calling code resolves here. |
| `currencies` | 25 | carries the true minor-unit exponent so JPY/KWD display correctly even though storage is always DECIMAL(12,2). |
| `flights` | 4,000 | Schedule instances across the search window, so a date search returns results rather than blanks. |
| `hotels` | 300 | Fewer, richer properties. Depth (reviews, room types, media) matters more than catalogue size —. |
| `itineraries` | 803 | A versioned plan belonging to a trip. version is what makes PS-11's conflict handling tractable. |
| `itinerary_items` | 8,583 | The atom of the portal, and the single most-shared object across the thirteen builds. If a team implements one shared shape, this is it. |
| `trips` | 600 | The container that gives dates, party, destination and budget to everything else. Seven statements produce or consume one. |
| `users` | 1,200 | The traveller identity every personalisation hangs off. Segmented heavy / light / cold_start so APS-04 can prove cold start. |
| `airlines` | 30 | Carrier reference for flight schedule instances. |
| `airports` | 80 | So flights join airport-to-airport rather than city-to-city. |
| `categories` | 70 | One two-level taxonomy shared by POI type, package theme and expense category — so the three never drift apart. |
| `events_festivals` | 300 | PS-13's 'what's on right now' depends entirely on this table plus the current date. |
| `flight_fares` | 8,002 | The bookable unit for flights, and the second entity_type in inventory_calendar. |
| `place_kb` | 1,200 | chunked, embeddable prose. If retrieval returns filler the grounding claim collapses, so this text is written to be worth retrieving. |
| `poi_travel_matrix` | 6,418 | precomputed edge costs between POIs. This is what removes the Google Maps dependency for APS-09 and makes results comparable across teams. |

## Reference tables, included so the database is valid

You will mostly join through these rather than think about them.

| Table | Rows | What it is |
|---|---|---|
| `languages` | 26 | Rule R6: BCP-47 is the only legal way to say 'language' anywhere in the model. |

## How they fit together

Open `02_DATA_MODEL_DIAGRAM.html` in a browser for the clickable version — it shows these tables and nothing else. Download it first; it will not render inside SharePoint.

Some tables point at "any bookable thing" using an `(entity_type, entity_id)` pair rather than a typed foreign key. That is deliberate: it is what lets one feature refer to a hotel, a flight, a point of interest or a package without a separate join table for each. The legal values of `entity_type` are in `data/enums.json`.

---

## Every field, table by table

Columns marked **PK** are the primary key. **FK** shows what a column points at. Enum columns list their legal values — anything else is rejected by the conformance check.

### `categories`

*Reference & geography · 70 rows · IDs start `cat_`*

One two-level taxonomy shared by POI type, package theme and expense category — so the three never drift apart.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `category_id` | text | **PK** | cat_ prefixed. |
| `code` | text | UNIQUE · NOT NULL | snake_case. |
| `label` | text | NOT NULL |  |
| `parent_category_id` | text | FK → `categories.category_id` | Null for top-level; self-referencing. |
| `applies_to` | text | NOT NULL | poi | package | expense | mixed. |
| `updated_at` | timestamptz | NOT NULL |  |

### `currencies`

*Reference & geography · 25 rows · IDs start `cur_`*

carries the true minor-unit exponent so JPY/KWD display correctly even though storage is always DECIMAL(12,2).

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `currency_id` | text | **PK** | cur_ prefixed. |
| `iso4217` | char(3) | UNIQUE · NOT NULL | e.g. INR. |
| `name` | text | NOT NULL |  |
| `symbol` | text | NOT NULL |  |
| `minor_unit_exponent` | smallint | NOT NULL | 0 for JPY/KRW, 2 default, 3 for KWD/BHD. |
| `display_locale` | text | NOT NULL | BCP-47 locale used for formatting. |
| `updated_at` | timestamptz | NOT NULL |  |

### `languages`

*Reference & geography · 26 rows · IDs start `lng_` · reference table*

Rule R6: BCP-47 is the only legal way to say 'language' anywhere in the model.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `language_id` | text | **PK** | lng_ prefixed. |
| `bcp47` | text | UNIQUE · NOT NULL | e.g. ta, hi, en-IN — never 'Tamil'. |
| `english_name` | text | NOT NULL |  |
| `native_name` | text | NOT NULL |  |
| `script` | text | NOT NULL | ISO-15924, e.g. Taml, Deva, Latn. |
| `rtl` | bool | NOT NULL | Right-to-left rendering flag. |
| `tts_supported` | bool | NOT NULL | Relevant to PS-13 voice output. |
| `updated_at` | timestamptz | NOT NULL |  |

### `countries`

*Reference & geography · 30 rows · IDs start `cnt_`*

ISO country reference. Every city, currency default and calling code resolves here.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `country_id` | text | **PK** | Canonical ID, cnt_ prefixed. |
| `iso2` | char(2) | UNIQUE · NOT NULL | ISO-3166-1 alpha-2, e.g. IN. |
| `iso3` | char(3) | UNIQUE · NOT NULL | ISO-3166-1 alpha-3, e.g. IND. |
| `name` | text | NOT NULL | English short name. |
| `default_currency` | char(3) | FK → `currencies.iso4217` · NOT NULL | ISO-4217 code. |
| `calling_code` | text | NOT NULL | E.164 country calling code, e.g. +91. |
| `region` | text | NOT NULL | UN sub-region grouping. |
| `updated_at` | timestamptz | NOT NULL | Rule R4: UTC, ISO-8601 with offset. |

### `airlines`

*Reference & geography · 30 rows · IDs start `arl_`*

Carrier reference for flight schedule instances.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `airline_id` | text | **PK** | arl_ prefixed. |
| `iata` | char(2) | UNIQUE · NOT NULL | Carrier code, e.g. 6E. |
| `name` | text | NOT NULL |  |
| `alliance` | text |  | star_alliance | oneworld | skyteam | none. |
| `country_id` | text | FK → `countries.country_id` · NOT NULL |  |
| `low_cost` | bool | NOT NULL | Drives fare banding. |
| `updated_at` | timestamptz | NOT NULL |  |

### `cities`

*Reference & geography · 60 rows · IDs start `cty_`*

The geographic anchor of the whole model. 60 cities; every hotel, POI, package, advisory and weather row hangs off one.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `city_id` | text | **PK** | cty_ prefixed. |
| `name` | text | NOT NULL | City name. |
| `state` | text |  | State / province, nullable for city-states. |
| `country_id` | text | FK → `countries.country_id` · NOT NULL |  |
| `country_code` | char(2) | NOT NULL | Denormalised ISO2 for convenient joins. |
| `lat` | decimal(9,6) | NOT NULL | Rule R7: WGS-84, 6dp. |
| `lng` | decimal(9,6) | NOT NULL | Rule R7: WGS-84, 6dp. |
| `timezone` | text | NOT NULL | IANA zone, e.g. Asia/Kolkata. |
| `region` | text | NOT NULL | Domestic region grouping, e.g. South India. |
| `population` | int |  | Approximate, for demand weighting. |
| `season_profile` | text | NOT NULL · one of `winter`, `summer`, `monsoon`, `post_monsoon`, `spring`, `autumn` | Dominant season at the peak travel window. |
| `peak_months` | text | NOT NULL | Comma-separated month numbers, e.g. 10,11,12. |
| `primary_language` | text | FK → `languages.bcp47` · NOT NULL | Rule R6: BCP-47 tag. |
| `description` | text |  | One-paragraph orientation blurb, used by PS-13. |
| `status` | text | NOT NULL · one of `active`, `inactive`, `archived`, `draft` |  |
| `updated_at` | timestamptz | NOT NULL |  |

### `events_festivals`

*Supply & catalogue · 300 rows · IDs start `evt_`*

PS-13's 'what's on right now' depends entirely on this table plus the current date.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `event_id` | text | **PK** | evt_ prefixed. |
| `city_id` | text | FK → `cities.city_id` · NOT NULL |  |
| `name` | text | NOT NULL |  |
| `category_id` | text | FK → `categories.category_id` · NOT NULL |  |
| `start_date` | date | NOT NULL |  |
| `end_date` | date | NOT NULL |  |
| `season` | text | NOT NULL · one of `winter`, `summer`, `monsoon`, `post_monsoon`, `spring`, `autumn` |  |
| `recurrence` | text | NOT NULL | annual | biennial | one_off. |
| `expected_footfall` | int |  |  |
| `is_ticketed` | bool | NOT NULL |  |
| `ticket_price` | decimal(12,2) |  |  |
| `currency` | char(3) | FK → `currencies.iso4217` |  |
| `venue_lat` | decimal(9,6) |  |  |
| `venue_lng` | decimal(9,6) |  |  |
| `description` | text | NOT NULL | Plausible prose. |
| `status` | text | NOT NULL · one of `active`, `inactive`, `archived`, `draft` |  |
| `updated_at` | timestamptz | NOT NULL |  |

### `hotels`

*Supply & catalogue · 300 rows · IDs start `htl_`*

Fewer, richer properties. Depth (reviews, room types, media) matters more than catalogue size —.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `hotel_id` | text | **PK** | htl_ prefixed. |
| `city_id` | text | FK → `cities.city_id` · NOT NULL |  |
| `name` | text | NOT NULL | ~3% near-duplicate names injected deliberately. |
| `property_type` | text | NOT NULL · one of `hotel`, `resort`, `homestay`, `hostel`, `apartment`, `boutique`, `heritage`, `guesthouse` |  |
| `star_rating` | smallint | NOT NULL | 1–5, CHECK constrained. |
| `guest_score` | decimal(2,1) |  | 0.0–10.0; null for a handful of new properties. |
| `review_count` | int | NOT NULL | Denormalised count, must agree with hotel_reviews. |
| `address_line` | text | NOT NULL |  |
| `lat` | decimal(9,6) | NOT NULL |  |
| `lng` | decimal(9,6) | NOT NULL |  |
| `distance_to_centre_km` | decimal(6,2) | NOT NULL | PS-02 filter: distance to a landmark. |
| `description` | text | NOT NULL | Plausible prose, embeddable. |
| `base_currency` | char(3) | FK → `currencies.iso4217` · NOT NULL |  |
| `checkin_time` | text | NOT NULL | Local HH:MM at the property. |
| `checkout_time` | text | NOT NULL |  |
| `chain_code` | text |  | Null for independents. |
| `has_xr_scene` | bool | NOT NULL | PS-05 / APS-07 — does an immersive preview exist. |
| `status` | text | NOT NULL · one of `active`, `inactive`, `archived`, `draft` |  |
| `created_at` | timestamptz | NOT NULL |  |
| `updated_at` | timestamptz | NOT NULL |  |

### `users`

*Identity & preference · 1,200 rows · IDs start `usr_`*

The traveller identity every personalisation hangs off. Segmented heavy / light / cold_start so APS-04 can prove cold start.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `user_id` | text | **PK** | usr_ prefixed. |
| `display_name` | text | NOT NULL | Synthetic — no real people (content policy). |
| `email` | text | UNIQUE · NOT NULL | Synthetic @example.invalid addresses only. |
| `home_city_id` | text | FK → `cities.city_id` · NOT NULL |  |
| `home_currency` | char(3) | FK → `currencies.iso4217` · NOT NULL |  |
| `locale` | text | FK → `languages.bcp47` · NOT NULL | UI language, BCP-47. |
| `budget_band` | text | NOT NULL · one of `shoestring`, `value`, `mid`, `premium`, `luxury` |  |
| `travel_style` | text | NOT NULL · one of `budget`, `comfort`, `luxury`, `adventure`, `slow`, `cultural`, `wellness` |  |
| `traveller_type` | text | NOT NULL · one of `solo`, `couple`, `family`, `business`, `friends`, `senior`, `backpacker` |  |
| `segment` | text | NOT NULL · one of `heavy`, `light`, `cold_start` | heavy / light / cold_start cohorts. |
| `date_of_signup` | date | NOT NULL |  |
| `loyalty_tier` | text |  | none | silver | gold — nullable by design. |
| `status` | text | NOT NULL · one of `active`, `inactive`, `archived`, `draft` |  |
| `created_at` | timestamptz | NOT NULL |  |
| `updated_at` | timestamptz | NOT NULL |  |

### `activities_poi`

*Supply & catalogue · 900 rows · IDs start `poi_`*

Points of interest with real depth — cost, duration, carbon, hours and tags — because APS-09 optimises over exactly these fields.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `poi_id` | text | **PK** | poi_ prefixed. |
| `city_id` | text | FK → `cities.city_id` · NOT NULL |  |
| `name` | text | NOT NULL |  |
| `category_id` | text | FK → `categories.category_id` · NOT NULL |  |
| `poi_category` | text | NOT NULL · one of `heritage`, `nature`, `museum`, `religious`, `adventure`, `food`, `shopping`, `nightlife`, `beach`, `wildlife`, `wellness`, `viewpoint` | Denormalised top-level category. |
| `lat` | decimal(9,6) | NOT NULL |  |
| `lng` | decimal(9,6) | NOT NULL |  |
| `typical_duration_minutes` | int | NOT NULL | APS-09 constraint input. |
| `entry_cost` | decimal(12,2) | NOT NULL | 0.00 where free. |
| `currency` | char(3) | FK → `currencies.iso4217` · NOT NULL |  |
| `carbon_kg` | decimal(8,3) | NOT NULL | On-site footprint estimate. |
| `popularity_score` | smallint | NOT NULL | 0–100, drives APS-04 baseline ranking. |
| `value_score` | smallint | NOT NULL | 0–100, the 'value' objective in APS-09. |
| `opens_at` | text |  | Local HH:MM; null where always open. |
| `closes_at` | text |  |  |
| `closed_days` | text |  | Comma-separated 0–6, 0 = Monday. |
| `best_season` | text | one of `winter`, `summer`, `monsoon`, `post_monsoon`, `spring`, `autumn` |  |
| `accessibility` | text | NOT NULL | step_free | partial | none. |
| `tags` | text | NOT NULL | Comma-separated free tags for hybrid retrieval. |
| `description` | text | NOT NULL | Plausible prose. |
| `has_xr_scene` | bool | NOT NULL | PS-05 / APS-07. |
| `status` | text | NOT NULL · one of `active`, `inactive`, `archived`, `draft` |  |
| `updated_at` | timestamptz | NOT NULL |  |

### `airports`

*Reference & geography · 80 rows · IDs start `apt_`*

So flights join airport-to-airport rather than city-to-city.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `airport_id` | text | **PK** | apt_ prefixed. |
| `iata` | char(3) | UNIQUE · NOT NULL | IATA code. |
| `icao` | char(4) |  | ICAO code. |
| `name` | text | NOT NULL |  |
| `city_id` | text | FK → `cities.city_id` · NOT NULL |  |
| `lat` | decimal(9,6) | NOT NULL |  |
| `lng` | decimal(9,6) | NOT NULL |  |
| `timezone` | text | NOT NULL | IANA. |
| `is_international` | bool | NOT NULL |  |
| `updated_at` | timestamptz | NOT NULL |  |

### `flights`

*Supply & catalogue · 4,000 rows · IDs start `flt_`*

Schedule instances across the search window, so a date search returns results rather than blanks.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `flight_id` | text | **PK** | flt_ prefixed. |
| `airline_id` | text | FK → `airlines.airline_id` · NOT NULL |  |
| `flight_number` | text | NOT NULL | e.g. 6E-2043. |
| `origin_airport_id` | text | FK → `airports.airport_id` · NOT NULL |  |
| `dest_airport_id` | text | FK → `airports.airport_id` · NOT NULL |  |
| `departs_at` | timestamptz | NOT NULL | Rule R4: carries offset. |
| `arrives_at` | timestamptz | NOT NULL |  |
| `duration_minutes` | int | NOT NULL |  |
| `stops` | smallint | NOT NULL |  |
| `aircraft_type` | text |  |  |
| `cabin_classes` | text | NOT NULL | Comma-separated cabin_class values available. |
| `carbon_kg` | decimal(8,3) | NOT NULL | Per-seat estimate — APS-09 reads this. |
| `status` | text | NOT NULL · one of `active`, `inactive`, `archived`, `draft` |  |
| `updated_at` | timestamptz | NOT NULL |  |

### `place_kb`

*Content, knowledge & safety · 1,200 rows · IDs start `kbc_`*

chunked, embeddable prose. If retrieval returns filler the grounding claim collapses, so this text is written to be worth retrieving.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `chunk_id` | text | **PK** | kbc_ prefixed. |
| `city_id` | text | FK → `cities.city_id` | One of city_id / poi_id is always set. |
| `poi_id` | text | FK → `activities_poi.poi_id` |  |
| `section` | text | NOT NULL · one of `history`, `culture`, `etiquette`, `food`, `transport`, `safety`, `seasonal`, `practical` |  |
| `title` | text | NOT NULL |  |
| `body` | text | NOT NULL | 120–260 words of plausible prose. |
| `language` | text | FK → `languages.bcp47` · NOT NULL |  |
| `token_estimate` | int | NOT NULL |  |
| `source_label` | text | NOT NULL | Synthetic provenance label, shown in citations. |
| `embedding_ref` | text |  | Row key into the precomputed embeddings parquet. |
| `seasonal_relevance` | text | one of `winter`, `summer`, `monsoon`, `post_monsoon`, `spring`, `autumn` | Null where the chunk is season-agnostic. |
| `updated_at` | timestamptz | NOT NULL |  |

### `poi_travel_matrix`

*Supply & catalogue · 6,418 rows · IDs start `ptm_`*

precomputed edge costs between POIs. This is what removes the Google Maps dependency for APS-09 and makes results comparable across teams.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `matrix_id` | text | **PK** | ptm_ prefixed. |
| `origin_poi_id` | text | FK → `activities_poi.poi_id` · NOT NULL |  |
| `dest_poi_id` | text | FK → `activities_poi.poi_id` · NOT NULL |  |
| `mode` | text | NOT NULL · one of `walk`, `cycle`, `auto_rickshaw`, `cab`, `bus`, `metro`, `train`, `ferry`, `flight` |  |
| `minutes` | int | NOT NULL |  |
| `distance_km` | decimal(7,3) | NOT NULL |  |
| `carbon_kg` | decimal(8,3) | NOT NULL |  |
| `cost` | decimal(12,2) | NOT NULL | 0.00 for walk. |
| `currency` | char(3) | FK → `currencies.iso4217` · NOT NULL |  |
| `bearing_deg` | smallint | NOT NULL | APS-03 wayfinding — bearing origin → destination. |
| `updated_at` | timestamptz | NOT NULL |  |

*Unique together:* `(origin_poi_id, dest_poi_id, mode)`

### `trips`

*Trip & itinerary · 600 rows · IDs start `trp_`*

The container that gives dates, party, destination and budget to everything else. Seven statements produce or consume one.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `trip_id` | text | **PK** | trp_ prefixed. |
| `owner_user_id` | text | FK → `users.user_id` · NOT NULL |  |
| `title` | text | NOT NULL |  |
| `origin_city_id` | text | FK → `cities.city_id` |  |
| `destination_city_id` | text | FK → `cities.city_id` · NOT NULL |  |
| `start_date` | date | NOT NULL | Rule R4: zoneless calendar date. |
| `end_date` | date | NOT NULL |  |
| `party_size` | smallint | NOT NULL |  |
| `adults` | smallint | NOT NULL |  |
| `children` | smallint | NOT NULL |  |
| `trip_type` | text | NOT NULL · one of `solo`, `couple`, `family`, `business`, `friends`, `senior`, `backpacker` |  |
| `is_group_trip` | bool | NOT NULL | PS-11 / PS-08 filter. |
| `status` | text | NOT NULL · one of `draft`, `planning`, `confirmed`, `in_progress`, `completed`, `cancelled` |  |
| `home_currency` | char(3) | FK → `currencies.iso4217` · NOT NULL |  |
| `notes` | text |  |  |
| `created_at` | timestamptz | NOT NULL |  |
| `updated_at` | timestamptz | NOT NULL |  |

### `flight_fares`

*Supply & catalogue · 8,002 rows · IDs start `far_`*

The bookable unit for flights, and the second entity_type in inventory_calendar.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `fare_id` | text | **PK** | far_ prefixed. |
| `flight_id` | text | FK → `flights.flight_id` · NOT NULL |  |
| `cabin_class` | text | NOT NULL · one of `economy`, `premium_economy`, `business`, `first` |  |
| `fare_class` | text | NOT NULL · one of `saver`, `flex`, `standard`, `corporate`, `promo` |  |
| `base_fare` | decimal(12,2) | NOT NULL | D3. |
| `taxes` | decimal(12,2) | NOT NULL |  |
| `currency` | char(3) | FK → `currencies.iso4217` · NOT NULL |  |
| `baggage_kg` | smallint | NOT NULL |  |
| `cabin_baggage_kg` | smallint | NOT NULL |  |
| `changeable` | bool | NOT NULL |  |
| `change_fee` | decimal(12,2) |  |  |
| `refundable` | bool | NOT NULL |  |
| `seats_total` | int | NOT NULL |  |
| `status` | text | NOT NULL · one of `active`, `inactive`, `archived`, `draft` |  |
| `updated_at` | timestamptz | NOT NULL |  |

### `itineraries`

*Trip & itinerary · 803 rows · IDs start `itn_`*

A versioned plan belonging to a trip. version is what makes PS-11's conflict handling tractable.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `itinerary_id` | text | **PK** | itn_ prefixed. |
| `trip_id` | text | FK → `trips.trip_id` · NOT NULL |  |
| `name` | text | NOT NULL |  |
| `version` | int | NOT NULL | Monotonic per itinerary. |
| `is_active` | bool | NOT NULL | Exactly one active version per trip. |
| `generated_by` | text | NOT NULL · one of `user`, `ai_planner`, `optimizer`, `agent`, `vote`, `import` | Which subsystem produced this version. |
| `total_cost` | decimal(12,2) | NOT NULL | sum of item costs, half-up at the end. |
| `currency` | char(3) | FK → `currencies.iso4217` · NOT NULL |  |
| `total_duration_minutes` | int | NOT NULL |  |
| `total_carbon_kg` | decimal(10,3) | NOT NULL | APS-09 objective. |
| `optimizer_weights` | text |  | JSON string: {cost, time, carbon} weights that produced it. |
| `status` | text | NOT NULL · one of `active`, `inactive`, `archived`, `draft` |  |
| `created_at` | timestamptz | NOT NULL |  |
| `updated_at` | timestamptz | NOT NULL |  |

### `itinerary_items`

*Trip & itinerary · 8,583 rows · IDs start `itm_`*

The atom of the portal, and the single most-shared object across the thirteen builds. If a team implements one shared shape, this is it.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `item_id` | text | **PK** | itm_ prefixed. |
| `itinerary_id` | text | FK → `itineraries.itinerary_id` · NOT NULL |  |
| `day_index` | smallint | NOT NULL | 1-based. |
| `sort_order` | smallint | NOT NULL | Order within the day. |
| `starts_at` | timestamptz |  | Rule R4: offset-carrying; null for unscheduled items. |
| `ends_at` | timestamptz |  |  |
| `item_type` | text | NOT NULL · one of `hotel`, `flight`, `poi`, `package`, `guide`, `transfer`, `meal`, `free` |  |
| `entity_type` | text | one of `hotel`, `room_type`, `rate_plan`, `flight`, `flight_fare`, `poi`, `package`, `package_component`, `guide`, `transfer`, `event`, `xr_scene` | Polymorphic supply reference. |
| `entity_id` | text |  | Canonical ID of the referenced supply row. |
| `title` | text | NOT NULL |  |
| `cost` | decimal(12,2) | NOT NULL | D3. |
| `currency` | char(3) | FK → `currencies.iso4217` · NOT NULL |  |
| `carbon_kg` | decimal(8,3) | NOT NULL |  |
| `duration_minutes` | int | NOT NULL |  |
| `source` | text | NOT NULL · one of `user`, `ai_planner`, `optimizer`, `agent`, `vote`, `import` | user | ai_planner | optimizer | agent | vote — makes a mixed plan auditable. |
| `explanation` | text |  | Where APS-04 and PS-01 surface reasoning without a parallel structure. |
| `locked` | bool | NOT NULL | APS-09 hard constraint: must-see items cannot be dropped. |
| `status` | text | NOT NULL · one of `proposed`, `confirmed`, `removed`, `replaced` | Rule R8: removed items stay visible. |
| `created_at` | timestamptz | NOT NULL |  |
| `updated_at` | timestamptz | NOT NULL |  |

---

## The rules that apply to these fields

| # | Rule |
|---|---|
| R1 | **Additive only.** Add columns, tables and stores freely. Never rename, drop or repurpose a field that came with the data. |
| R2 | **IDs are opaque prefixed strings** — `htl_a91f3c`. Never integers, never parsed for meaning. |
| R3 | **Money is a pair**: a 2-place decimal plus an ISO-4217 currency code. Never a float. |
| R4 | **Time is ISO-8601 with an offset.** `_at` fields carry an offset; `_date` fields have no zone. |
| R5 | **Enums are lowercase snake_case** and the legal values are in `data/enums.json`. |
| R6 | **Language is a BCP-47 tag** — `ta`, not "Tamil". |
| R7 | **Geography is WGS-84** to 6 decimal places, `lat` and `lng` together or not at all. |
| R8 | **Nothing is hard-deleted.** Rows carry `status` and `updated_at`. |

Add whatever you like beside these fields — new columns, new tables, your own vector store, your own services. That is the point of R1. What you must not do is rename or re-key the fields that came with the data, because that is what would stop sixteen independent builds being put together afterwards.

`data/WORKING_WITH_THE_DATA.md` has the loading instructions, including how to read money without corrupting it. `tools/validate_conformance.py` tells you in thirty seconds whether you are still conformant.
