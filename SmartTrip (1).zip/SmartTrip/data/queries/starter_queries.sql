-- PS-01 — SmartTrip — AI Travel Planner
-- Starter queries. Every one runs as-is against data/PS-01.db.
--
-- CAST(x AS REAL) appears below only for sorting and rough exploration.
-- Never use it for a value you will show someone or add to another value.

-- ==========================================================================
-- 1. Pick a destination and see what you have to plan with
-- Counts per city. Start with a city that has depth.
-- ==========================================================================
SELECT c.name AS city, c.timezone,
          (SELECT COUNT(*) FROM hotels h WHERE h.city_id=c.city_id)          AS hotels,
          (SELECT COUNT(*) FROM activities_poi p WHERE p.city_id=c.city_id)  AS pois,
          (SELECT COUNT(*) FROM place_kb k WHERE k.city_id=c.city_id)        AS kb_chunks
     FROM cities c ORDER BY pois DESC, hotels DESC LIMIT 10;

-- ==========================================================================
-- 2. A complete existing itinerary, day by day
-- This is the shape your planner has to emit. Note source and explanation — a mixed human/AI plan is auditable because of those two columns.
-- ==========================================================================
SELECT i.day_index, i.sort_order, i.starts_at, i.item_type, i.title,
          i.cost, i.currency, i.carbon_kg, i.source, i.explanation
     FROM itinerary_items i
     JOIN itineraries it ON it.itinerary_id = i.itinerary_id
    WHERE it.is_active = 1 AND i.status <> 'removed'
      AND it.itinerary_id = (SELECT itinerary_id FROM itineraries
                              WHERE is_active=1 ORDER BY itinerary_id LIMIT 1)
    ORDER BY i.day_index, i.sort_order;

-- ==========================================================================
-- 3. Candidate POIs for a day plan, with everything the planner needs
-- Cost is a decimal string — CAST only for ordering, never for arithmetic you will show the user.
-- ==========================================================================
SELECT p.name, p.poi_category, p.typical_duration_minutes,
          p.entry_cost, p.currency, p.opens_at, p.closes_at, p.popularity_score, p.tags
     FROM activities_poi p
     JOIN cities c ON c.city_id = p.city_id
    WHERE c.name = 'Jaipur' AND p.status='active'
    ORDER BY p.popularity_score DESC LIMIT 15;

-- ==========================================================================
-- 4. Flights between two cities inside the search window
-- Fares are per flight instance; join through airports, not cities.
-- ==========================================================================
SELECT f.flight_number, ao.iata AS from_ap, ad.iata AS to_ap,
          f.departs_at, f.duration_minutes, f.stops,
          fa.cabin_class, fa.base_fare, fa.taxes, fa.currency
     FROM flights f
     JOIN airports ao ON ao.airport_id = f.origin_airport_id
     JOIN airports ad ON ad.airport_id = f.dest_airport_id
     JOIN flight_fares fa ON fa.flight_id = f.flight_id
    WHERE date(f.departs_at) BETWEEN '2026-09-10' AND '2026-09-20'
    ORDER BY f.departs_at LIMIT 20;

-- ==========================================================================
-- 5. Grounding chunks for RAG on one city
-- place_kb is written as prose on purpose. Embed body, cite source_label.
-- ==========================================================================
SELECT k.section, k.title, k.token_estimate, substr(k.body,1,120) AS opening
     FROM place_kb k JOIN cities c ON c.city_id = k.city_id
    WHERE c.name = 'Kochi' ORDER BY k.section;

-- ==========================================================================
-- 6. Running budget for an itinerary
-- Sum in the database only to explore. In your app, sum with Decimal / BigDecimal.
-- ==========================================================================
SELECT it.itinerary_id, it.currency,
          COUNT(*) AS items, it.total_cost, it.total_carbon_kg
     FROM itineraries it JOIN itinerary_items i ON i.itinerary_id = it.itinerary_id
    WHERE it.is_active = 1 AND i.status <> 'removed'
    GROUP BY it.itinerary_id ORDER BY CAST(it.total_cost AS REAL) DESC LIMIT 10;
